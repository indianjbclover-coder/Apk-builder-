package com.osamu.aide.editor

import android.content.Context
import com.itsaky.androidide.treesitter.TSLanguage
import com.itsaky.androidide.treesitter.c.TSLanguageC
import com.itsaky.androidide.treesitter.cpp.TSLanguageCpp
import com.itsaky.androidide.treesitter.java.TSLanguageJava
import com.itsaky.androidide.treesitter.json.TSLanguageJson
import com.itsaky.androidide.treesitter.kotlin.TSLanguageKotlin
import com.itsaky.androidide.treesitter.python.TSLanguagePython
import com.itsaky.androidide.treesitter.xml.TSLanguageXml
import com.osamu.aide.editor.treesitter.JavaScriptGrammar
import io.github.rosemoe.sora.editor.ts.TsLanguageSpec
import io.github.rosemoe.sora.lang.EmptyLanguage
import io.github.rosemoe.sora.lang.Language
import java.io.File

/**
 * The languages the editor can highlight, and which files each one claims.
 *
 * Highlighting is tree-sitter rather than TextMate: it parses to a real syntax
 * tree and reparses only what changed, which is what keeps a 5,000-line file
 * scrolling smoothly while it is being typed into. The cost is that grammars
 * are native code -- see `assets/treesitter/README.md` for where they and their
 * queries come from.
 */
enum class EditorLanguage(
    val displayName: String,
    private val extensions: Set<String>,
    val queryDirectory: String,
    private val grammar: () -> TSLanguage,
) {
    JAVA("Java", setOf("java"), "java", { TSLanguageJava.getInstance() }),
    KOTLIN("Kotlin", setOf("kt", "kts"), "kotlin", { TSLanguageKotlin.getInstance() }),
    XML("XML", setOf("xml"), "xml", { TSLanguageXml.getInstance() }),
    JSON("JSON", setOf("json"), "json", { TSLanguageJson.getInstance() }),

    /**
     * Python, from the same publisher as Java and Kotlin.
     *
     * `.pyw` as well as `.py` because Windows uses it for a script with no
     * console, and a repository cloned onto the phone carries whatever the
     * author wrote. `.pyi` is a stub file and parses with this grammar too --
     * it is Python syntax with the bodies elided.
     */
    PYTHON("Python", setOf("py", "pyw", "pyi"), "python", { TSLanguagePython.getInstance() }),

    /**
     * C, for `src/main/cpp` and anything cloned that holds it.
     *
     * Missing until the grammar was added, and what that looked like was not an
     * error: every C and C++ file opened as plain text, in an app whose native
     * templates exist to show them off.
     */
    C("C", setOf("c"), "c", { TSLanguageC.getInstance() }),

    /**
     * C++, and **every `.h`**.
     *
     * A header does not say which language it is, and the two grammars fail in
     * opposite directions: C++'s parses nearly all C, while C's stops at the
     * first `class`, `namespace` or `template` and leaves the rest of the
     * declaration uncoloured. The JNI template's headers are C++, and a C
     * header read as C++ loses almost nothing.
     *
     * The query is upstream's `highlights.scm` concatenated **after** C's,
     * because tree-sitter-cpp's own `tree-sitter.json` declares its highlights
     * as both files: its query only adds C++ on top and says nothing about
     * comments, strings or most keywords.
     */
    CPP(
        "C++",
        setOf("cpp", "cc", "cxx", "c++", "h", "hh", "hpp", "hxx", "inl"),
        "cpp",
        { TSLanguageCpp.getInstance() },
    ),

    /**
     * The one grammar this project builds itself; see [JavaScriptGrammar].
     *
     * `.mjs` and `.cjs` are the same language — a Node project can hold either
     * the moment it declares a module type — and both parse with this grammar.
     * `.jsx` deliberately does not: upstream ships a separate
     * `highlights-jsx.scm`, and claiming the extension without it would
     * highlight JSX as if the tags were syntax errors.
     */
    JAVASCRIPT(
        "JavaScript",
        setOf("js", "mjs", "cjs"),
        "javascript",
        { JavaScriptGrammar.language() },
    ),

    /**
     * The same grammar, a longer query.
     *
     * tree-sitter-javascript parses JSX already; what `.jsx` needs is
     * upstream's `highlights-jsx.scm`, which is written to be applied **on top
     * of** `highlights.scm` rather than instead of it. A language gets one
     * query, so `tools/treesitter/build-grammars.sh` concatenates the two into
     * a directory of its own -- and this entry exists rather than adding `jsx`
     * to [JAVASCRIPT]'s extensions because those files would then be
     * highlighted by the query that has no idea what a tag is.
     */
    JSX("JSX", setOf("jsx"), "javascriptx", { JavaScriptGrammar.language() });

    fun language(): TSLanguage = grammar()

    companion object {
        /** Null for anything unrecognised, which the editor shows as plain text. */
        fun of(file: File): EditorLanguage? {
            val extension = file.extension.lowercase()
            return entries.firstOrNull { extension in it.extensions }
        }
    }
}

/**
 * Builds the sora [Language] for a file.
 *
 * One [Language] per editor per file: nothing here is shared between editors,
 * and the reason is ownership rather than taste -- see [specFor].
 */
class EditorLanguages(private val context: Context) {

    /**
     * Where proposals come from, when anything can supply them.
     *
     * Settable rather than injected because it arrives late and can change:
     * Java intelligence needs `android.jar`, which is a download the user may
     * not have made yet, and it is per-project besides. A language built before
     * the service exists still picks it up, because it reads this at completion
     * time rather than capturing it at construction.
     *
     * Volatile: written from the main thread when a project opens, read from
     * sora's completion worker.
     */
    @Volatile
    var completionSource: CompletionSource? = null

    /**
     * The query *text*, not the compiled spec.
     *
     * Caching the spec is the obvious optimisation and is wrong. sora's
     * `TsLanguage.destroy()` closes the spec it was constructed with, and
     * `CodeEditor.setEditorLanguage` destroys the outgoing language -- so a
     * spec shared between two files is closed the moment the second one is
     * opened, and every language built from it afterwards throws
     * "spec is closed". Reading a query out of assets is what is left, and it
     * is a few kilobytes.
     */
    private val queries = mutableMapOf<EditorLanguage, String>()

    @Synchronized
    fun languageFor(file: File): Language {
        // Ordered, not incidental: touching a grammar before the core is loaded
        // throws UnsatisfiedLinkError from inside a static initialiser, which
        // then poisons the class for the life of the process.
        if (!TreeSitterRuntime.isAvailable) return EmptyLanguage()

        val language = EditorLanguage.of(file) ?: return EmptyLanguage()
        return CompletingTsLanguage(
            spec = specFor(language),
            file = file,
            // Read per request, not captured: see [completionSource].
            source = { completionSource },
        ) { EditorTheme.applyTo(this) }
    }

    private fun specFor(language: EditorLanguage): TsLanguageSpec = TsLanguageSpec(
        language = language.language(),
        highlightScmSource = queries.getOrPut(language) { query(language, "highlights.scm") },
        // Blocks, brackets and locals are separate queries the grammars do not
        // ship, and the features built on them -- folding markers, bracket
        // matching, scope-aware highlighting -- are not worth blocking syntax
        // colouring on. They cannot be left empty though: the binding rejects a
        // blank query outright, so these are comments, which compile to no
        // patterns and mean the same thing.
        codeBlocksScmSource = NO_PATTERNS,
        bracketsScmSource = NO_PATTERNS,
        localsScmSource = NO_PATTERNS,
    )

    private companion object {
        /** A query with nothing in it. Blank is rejected; a comment is not. */
        const val NO_PATTERNS = "; intentionally empty"
    }

    private fun query(language: EditorLanguage, name: String): String = context.assets
        .open("treesitter/${language.queryDirectory}/$name")
        .bufferedReader()
        .use { it.readText() }
}
