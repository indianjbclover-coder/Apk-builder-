package com.osamu.aide.ai.core

import com.anthropic.models.messages.OutputConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Gemini API client for AIDE-OS.
 *
 * Implements native Function Calling, system instructions, thinking config,
 * and handles both Google OAuth 2.0 access tokens and Gemini API keys.
 */
class GeminiAiClient(
    private val apiKey: String? = null,
    private val oauthToken: String? = null,
    override val model: String = AiProviderType.GEMINI.defaultModel,
    private val customEndpoint: String? = null,
    private val httpClient: OkHttpClient = OkHttpClient(),
) : AiClient {

    override val provider: AiProviderType = AiProviderType.GEMINI

    override suspend fun send(request: AiClientRequest): AiClientResponse = withContext(Dispatchers.IO) {
        val url = customEndpoint ?: "$BASE_URL/models/$model:generateContent"

        httpClient.newCall(turnRequest(request, url)).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Gemini request failed (${response.code}): $responseBody")
            }
            parseResponse(responseBody)
        }
    }

    /**
     * The streamed form of [send].
     *
     * **The verb carries the difference, not a flag.** Gemini streams from a
     * different route -- `:streamGenerateContent?alt=sse` -- so the URL is
     * rewritten rather than the body. Rewriting by substring means a custom
     * endpoint (which is how the tests reach a local server, and how a proxy
     * would be configured) streams through exactly the same transformation as
     * the default one, instead of only the default route being exercised.
     *
     * Without `alt=sse` this route returns a **JSON array of chunks** rather
     * than an event stream: a valid response that an SSE reader sees as one
     * unparseable blob, so the reply would arrive empty with no error anywhere.
     */
    override suspend fun send(
        request: AiClientRequest,
        onTextDelta: (String) -> Unit,
    ): AiClientResponse = withContext(Dispatchers.IO) {
        val base = customEndpoint ?: "$BASE_URL/models/$model:generateContent"
        val url = base.replace(":generateContent", ":streamGenerateContent") +
            if ("alt=sse" in base) "" else (if ('?' in base) "&" else "?") + "alt=sse"

        httpClient.newCall(turnRequest(request, url)).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException(
                    "Gemini request failed (${response.code}): ${response.body?.string().orEmpty()}",
                )
            }
            val body = response.body ?: throw IllegalStateException("Gemini returned no body to stream.")

            val accumulator = GeminiStreamAccumulator()
            body.charStream().buffered().use { reader ->
                forEachSseData(reader) { data -> accumulator.accept(data)?.let(onTextDelta) }
            }
            AiClientResponse(parts = accumulator.parts(), finishReason = accumulator.finishReason())
        }
    }

    private fun turnRequest(request: AiClientRequest, url: String): Request {
        val payload = JSONObject().apply {
            if (request.systemInstruction.isNotBlank()) {
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", request.systemInstruction)))
                })
            }

            put("contents", encodeContents(request.messages))

            if (request.tools.isNotEmpty()) {
                put("tools", JSONArray().put(JSONObject().apply {
                    put("function_declarations", encodeFunctionDeclarations(request.tools))
                }))
            }

            put("generationConfig", JSONObject().apply {
                put("temperature", 0.2)
                put("maxOutputTokens", request.maxTokens)
                if (model in THINKING_MODELS) {
                    val budget = if (request.effort == OutputConfig.Effort.LOW) 512 else 2048
                    put("thinkingConfig", JSONObject().put("thinkingBudget", budget))
                }
            })
        }

        return Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .apply {
                when {
                    !oauthToken.isNullOrBlank() -> header("Authorization", "Bearer $oauthToken")
                    !apiKey.isNullOrBlank() -> header("x-goog-api-key", apiKey)
                }
            }
            .build()
    }

    override suspend fun complete(context: CompletionContext): String? = withContext(Dispatchers.IO) {
        val url = customEndpoint ?: "$BASE_URL/models/$model:generateContent"

        val prompt = buildString {
            append("File: ").append(context.path).append("\n\n")
            append("<before_cursor>\n")
            append(context.before.takeLast(4000))
            append("\n</before_cursor>\n\n")
            append("<after_cursor>\n")
            append(context.after.take(1000))
            append("\n</after_cursor>")
        }

        val payload = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", COMPLETION_INSTRUCTIONS)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.1)
                put("maxOutputTokens", 256)
            })
        }

        val httpRequest = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .apply {
                when {
                    !oauthToken.isNullOrBlank() -> header("Authorization", "Bearer $oauthToken")
                    !apiKey.isNullOrBlank() -> header("x-goog-api-key", apiKey)
                }
            }
            .build()

        httpClient.newCall(httpRequest).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) return@withContext null
            val parsed = parseResponse(responseBody)
            cleanCompletion(parsed.text).takeIf { it.isNotEmpty() }
        }
    }

    private fun encodeContents(messages: List<AiMessage>): JSONArray {
        val array = JSONArray()
        for (message in messages) {
            val role = if (message.role == AiRole.USER) "user" else "model"
            val partsArray = JSONArray()

            for (part in message.parts) {
                when (part) {
                    is AiPart.Text -> {
                        partsArray.put(JSONObject().put("text", part.text))
                    }
                    is AiPart.Thought -> {
                        partsArray.put(JSONObject().put("text", part.thought))
                    }
                    is AiPart.FunctionCall -> {
                        val callObj = JSONObject().apply {
                            put("name", part.name)
                            put("args", JSONObject(part.args))
                        }
                        partsArray.put(JSONObject().put("functionCall", callObj))
                    }
                    is AiPart.FunctionResponse -> {
                        val respObj = JSONObject().apply {
                            put("name", part.name)
                            put("response", JSONObject().apply {
                                put("content", part.content)
                                put("is_error", part.isError)
                            })
                        }
                        partsArray.put(JSONObject().put("functionResponse", respObj))
                    }
                }
            }

            if (partsArray.length() > 0) {
                array.put(JSONObject().apply {
                    put("role", role)
                    put("parts", partsArray)
                })
            }
        }
        return array
    }

    private fun encodeFunctionDeclarations(tools: List<AideTool>): JSONArray {
        val array = JSONArray()
        for (tool in tools) {
            val decl = JSONObject().apply {
                put("name", tool.name)
                put("description", tool.description)

                val propertiesObj = JSONObject()
                val requiredArray = JSONArray()

                tool.parameters.forEach { (name, param) ->
                    propertiesObj.put(name, JSONObject().apply {
                        put("type", param.type.uppercase())
                        put("description", param.description)
                    })
                }
                tool.required.forEach { requiredArray.put(it) }

                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", propertiesObj)
                    if (requiredArray.length() > 0) {
                        put("required", requiredArray)
                    }
                })
            }
            array.put(decl)
        }
        return array
    }

    private fun parseResponse(body: String): AiClientResponse {
        val json = JSONObject(body)
        val candidates = json.optJSONArray("candidates") ?: return AiClientResponse(emptyList())
        if (candidates.length() == 0) return AiClientResponse(emptyList())

        val candidate = candidates.getJSONObject(0)
        val finishReason = candidate.stringOrNull("finishReason")
        val content = candidate.optJSONObject("content") ?: return AiClientResponse(emptyList(), finishReason)
        val partsArray = content.optJSONArray("parts") ?: return AiClientResponse(emptyList(), finishReason)

        val resultParts = mutableListOf<AiPart>()
        for (i in 0 until partsArray.length()) {
            val partObj = partsArray.getJSONObject(i)
            if (partObj.has("text")) {
                partObj.stringOrNull("text")?.let { resultParts += AiPart.Text(it) }
            } else if (partObj.has("functionCall")) {
                val callObj = partObj.getJSONObject("functionCall")
                val name = callObj.getString("name")
                val argsObj = callObj.optJSONObject("args")
                val argsMap = argsObj?.stringArguments().orEmpty()
                resultParts += AiPart.FunctionCall(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    args = argsMap,
                )
            }
        }

        return AiClientResponse(parts = resultParts, finishReason = finishReason)
    }

    companion object {
        /**
         * Models that take a `thinkingConfig`, named rather than pattern-matched.
         *
         * This was `model.contains("3.7") || model.contains("flash")`, which is
         * the same rot `FINDINGS.md` section 14 records for model ids: a
         * version substring that no build or startup check can catch. It read
         * as "3.7 and flash models think", and meant a `gemini-4-pro` would
         * silently lose its thinking budget while `gemini-3.1-pro-preview`
         * already did.
         *
         * An explicit set makes adding a model a decision instead of an
         * accident, and `GeminiAiClientTest` fails if a model reaches the
         * picker without appearing here or in [NON_THINKING_MODELS] -- so the
         * omission is caught at build time rather than as quietly worse answers.
         *
         * **Not verified against the API.** Which models accept the field is
         * unmeasured -- the account has no billing credit -- so this reflects
         * the previous behaviour plus the pro models it appeared to miss.
         * Sending the field to a model that rejects it is a 400; omitting it
         * where it is supported only costs quality, so an unknown model is
         * treated as non-thinking.
         */
        val THINKING_MODELS = setOf(
            "gemini-3.8-flash",
            "gemini-3.7-flash",
            "gemini-3.5-flash-lite",
            "gemini-3.1-pro-preview",
        )

        /** Models deliberately classified as taking no `thinkingConfig`. */
        val NON_THINKING_MODELS = emptySet<String>()

        const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        private val COMPLETION_INSTRUCTIONS = """
            You complete code at a cursor inside an IDE on the user's phone.

            Reply with the code that belongs at the cursor and nothing else: no
            explanation, no markdown fence, no repetition of the text before the
            cursor. Match the surrounding indentation and style.

            Complete the current line or the current small block. Do not write
            the rest of the file. If nothing useful can be added at the cursor,
            reply with nothing at all.
        """.trimIndent()
    }
}
