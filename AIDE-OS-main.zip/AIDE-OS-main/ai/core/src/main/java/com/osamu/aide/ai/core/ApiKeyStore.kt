package com.osamu.aide.ai.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Holds AI provider credentials encrypted against the Android Keystore.
 *
 * Supports multi-model providers with [AiProviderType.GEMINI] as the flagship default.
 * Credentials (Gemini API key, Google OAuth tokens, OpenAI key, Anthropic key) are
 * encrypted with hardware-backed Keystore keys and never leave the device in plaintext.
 *
 * Backward-compatible with earlier single-provider methods ([read], [save], [baseUrl]).
 */
class ApiKeyStore(
    context: Context,
    /**
     * Keeps a second, separate store beside the real one, for tests.
     *
     * **The app's own device tests run in the app's process**, where the real
     * store lives, and they clear it before and after every test -- so a
     * targeted run on a phone, which CLAUDE.md recommends, erased the user's
     * provider keys, Google sign-in and endpoints. Restoring afterwards cannot work: clearing deletes the Keystore key
     * the saved values are encrypted with. A test passes a namespace, and both
     * the preferences file and the Keystore alias are then its own.
     */
    private val namespace: String? = null,
) {

    private val preferences = context.getSharedPreferences(namespaced(FILE), Context.MODE_PRIVATE)

    // -- Active Provider & Model Settings -----------------------------------

    fun activeProvider(): AiProviderType {
        val storedId = preferences.getString(KEY_ACTIVE_PROVIDER, null)
        return if (storedId != null) {
            AiProviderType.fromId(storedId)
        } else {
            // If legacy Anthropic key exists and no active provider was set, keep Anthropic
            if (preferences.contains(KEY_CIPHERTEXT)) AiProviderType.ANTHROPIC else AiProviderType.DEFAULT
        }
    }

    fun setActiveProvider(provider: AiProviderType) {
        preferences.edit().putString(KEY_ACTIVE_PROVIDER, provider.id).commit()
    }

    fun activeModel(provider: AiProviderType = activeProvider()): String {
        return preferences.getString(modelKey(provider), null) ?: provider.defaultModel
    }

    fun setActiveModel(provider: AiProviderType, model: String) {
        preferences.edit().putString(modelKey(provider), model).commit()
    }

    fun shareProjectContext(): Boolean =
        preferences.getBoolean(KEY_SHARE_CONTEXT, true)

    fun setShareProjectContext(share: Boolean) {
        preferences.edit().putBoolean(KEY_SHARE_CONTEXT, share).commit()
    }

    // -- Status Checks ------------------------------------------------------

    /** True when a key or token is saved for the active provider, or legacy key exists. */
    fun hasKey(): Boolean = when (activeProvider()) {
        AiProviderType.GEMINI -> hasGemini()
        AiProviderType.OPENAI -> hasOpenAi()
        AiProviderType.ANTHROPIC -> hasAnthropic()
        AiProviderType.CUSTOM -> hasCustom()
        // **There is no key, and that is not a missing feature.** The server
        // is a process this app started on its own loopback; there is nobody
        // to authenticate to. Answering true would be a lie and answering
        // false reads as "not configured", so [isReady] is the question worth
        // asking about this provider and it does not consult a key at all.
        AiProviderType.LOCAL -> false
    }

    fun hasProviderKey(provider: AiProviderType): Boolean = when (provider) {
        AiProviderType.GEMINI -> hasGemini()
        AiProviderType.OPENAI -> hasOpenAi()
        AiProviderType.ANTHROPIC -> hasAnthropic()
        AiProviderType.CUSTOM -> hasCustom()
        AiProviderType.LOCAL -> false
    }

    private fun hasGemini(): Boolean =
        preferences.contains(KEY_GEMINI_KEY_CIPHER) || preferences.contains(KEY_GOOGLE_ACCESS_TOKEN_CIPHER)

    private fun hasOpenAi(): Boolean =
        preferences.contains(KEY_OPENAI_KEY_CIPHER)

    private fun hasAnthropic(): Boolean =
        preferences.contains(KEY_CIPHERTEXT) || preferences.contains(KEY_ANTHROPIC_KEY_CIPHER)

    // A key, and only a key. It used to be "a key or an address", so a key
    // saved under Custom with no address counted as a usable provider -- and
    // the client, given no address, sent that key to api.openai.com.
    private fun hasCustom(): Boolean =
        preferences.contains(KEY_CUSTOM_KEY_CIPHER)

    /**
     * Whether [provider] can be sent a request, which is not always "has a key".
     *
     * **Custom is ready when it has an address.** Its key is optional -- Ollama
     * wants none -- and without an address there is nowhere to send anything.
     * The other three are ready exactly when they hold a key.
     *
     * Found on a phone: Custom chosen, a key pasted, no address, and the chat
     * answered with OpenAI's 404 for `llama3.3:70b`. The request, and the key,
     * had gone to OpenAI.
     */
    fun isReady(provider: AiProviderType): Boolean = when (provider) {
        AiProviderType.CUSTOM -> !customBaseUrl().isNullOrBlank()
        // **Ready when a server is listening**, which is a running process
        // rather than a stored secret, so whoever started it writes the
        // address here and clears it on stop. Nothing else can know: the port
        // is chosen at launch.
        AiProviderType.LOCAL -> !localBaseUrl().isNullOrBlank()
        else -> hasProviderKey(provider)
    }

    // -- Legacy & Anthropic Compatibility -----------------------------------

    /**
     * Reads the active credential. If Anthropic is active (or legacy), reads the legacy key.
     * If Gemini is active, reads the Gemini API key or OAuth token.
     */
    fun read(): String? {
        return when (activeProvider()) {
            AiProviderType.ANTHROPIC -> decryptPreference(KEY_CIPHERTEXT, KEY_IV)
                ?: decryptPreference(KEY_ANTHROPIC_KEY_CIPHER, KEY_ANTHROPIC_IV)
            AiProviderType.GEMINI -> geminiApiKey() ?: googleAccessToken()
            AiProviderType.OPENAI -> openAiApiKey()
            AiProviderType.CUSTOM -> customApiKey()
            AiProviderType.LOCAL -> null
        }
    }

    /** Legacy save: preserves exact test behavior and writes to legacy keys. */
    fun save(apiKey: String) {
        encryptAndStore(KEY_CIPHERTEXT, KEY_IV, apiKey)
    }

    fun baseUrl(): String? = preferences.getString(KEY_BASE_URL, null)

    fun saveBaseUrl(endpoint: Endpoint) {
        val editor = preferences.edit()
        when (endpoint) {
            is Endpoint.Custom -> editor.putString(KEY_BASE_URL, endpoint.baseUrl)
            Endpoint.Default -> editor.remove(KEY_BASE_URL)
            is Endpoint.Rejected -> return
        }
        editor.commit()
    }

    // -- Google / Gemini Credentials ----------------------------------------

    fun geminiApiKey(): String? =
        decryptPreference(KEY_GEMINI_KEY_CIPHER, KEY_GEMINI_IV)

    fun saveGeminiApiKey(key: String) {
        encryptAndStore(KEY_GEMINI_KEY_CIPHER, KEY_GEMINI_IV, key)
    }

    fun clearGeminiApiKey() {
        preferences.edit()
            .remove(KEY_GEMINI_KEY_CIPHER)
            .remove(KEY_GEMINI_IV)
            .commit()
    }

    fun isGoogleSignedIn(): Boolean =
        preferences.contains(KEY_GOOGLE_ACCESS_TOKEN_CIPHER)

    fun googleAccessToken(): String? =
        decryptPreference(KEY_GOOGLE_ACCESS_TOKEN_CIPHER, KEY_GOOGLE_ACCESS_TOKEN_IV)

    fun googleRefreshToken(): String? =
        decryptPreference(KEY_GOOGLE_REFRESH_TOKEN_CIPHER, KEY_GOOGLE_REFRESH_TOKEN_IV)

    fun googleUserEmail(): String? =
        preferences.getString(KEY_GOOGLE_USER_EMAIL, null)

    fun googleUserName(): String? =
        preferences.getString(KEY_GOOGLE_USER_NAME, null)

    fun googleGrantedScopes(): String? =
        preferences.getString(KEY_GOOGLE_GRANTED_SCOPES, null)

    fun saveGoogleOAuth(
        accessToken: String,
        refreshToken: String? = null,
        email: String? = null,
        name: String? = null,
        grantedScopes: String? = null,
    ) {
        encryptAndStore(KEY_GOOGLE_ACCESS_TOKEN_CIPHER, KEY_GOOGLE_ACCESS_TOKEN_IV, accessToken)
        if (refreshToken != null) {
            encryptAndStore(KEY_GOOGLE_REFRESH_TOKEN_CIPHER, KEY_GOOGLE_REFRESH_TOKEN_IV, refreshToken)
        }
        val editor = preferences.edit()
        if (email != null) editor.putString(KEY_GOOGLE_USER_EMAIL, email)
        if (name != null) editor.putString(KEY_GOOGLE_USER_NAME, name)
        if (grantedScopes != null) editor.putString(KEY_GOOGLE_GRANTED_SCOPES, grantedScopes)
        editor.commit()
    }

    fun signOutGoogle() {
        preferences.edit()
            .remove(KEY_GOOGLE_ACCESS_TOKEN_CIPHER)
            .remove(KEY_GOOGLE_ACCESS_TOKEN_IV)
            .remove(KEY_GOOGLE_REFRESH_TOKEN_CIPHER)
            .remove(KEY_GOOGLE_REFRESH_TOKEN_IV)
            .remove(KEY_GOOGLE_USER_EMAIL)
            .remove(KEY_GOOGLE_USER_NAME)
            .remove(KEY_GOOGLE_GRANTED_SCOPES)
            .commit()
    }

    // -- OpenAI Credentials -------------------------------------------------

    fun openAiApiKey(): String? =
        decryptPreference(KEY_OPENAI_KEY_CIPHER, KEY_OPENAI_IV)

    fun saveOpenAiApiKey(key: String) {
        encryptAndStore(KEY_OPENAI_KEY_CIPHER, KEY_OPENAI_IV, key)
    }

    fun openAiBaseUrl(): String? =
        preferences.getString(KEY_OPENAI_BASE_URL, null)

    fun saveOpenAiBaseUrl(url: String?) {
        val editor = preferences.edit()
        if (url.isNullOrBlank()) editor.remove(KEY_OPENAI_BASE_URL) else editor.putString(KEY_OPENAI_BASE_URL, url.trim())
        editor.commit()
    }

    // -- Custom Provider Credentials ----------------------------------------

    fun customApiKey(): String? =
        decryptPreference(KEY_CUSTOM_KEY_CIPHER, KEY_CUSTOM_IV)

    fun saveCustomApiKey(key: String) {
        encryptAndStore(KEY_CUSTOM_KEY_CIPHER, KEY_CUSTOM_IV, key)
    }

    fun customBaseUrl(): String? =
        preferences.getString(KEY_CUSTOM_BASE_URL, null)

    fun saveCustomBaseUrl(url: String?) {
        val editor = preferences.edit()
        if (url.isNullOrBlank()) editor.remove(KEY_CUSTOM_BASE_URL) else editor.putString(KEY_CUSTOM_BASE_URL, url.trim())
        editor.commit()
    }

    /**
     * Where the on-device server is listening, or null when none is.
     *
     * **Not a setting.** Nobody types this: the port is chosen when the server
     * starts, so whatever starts it writes the address and clears it on stop.
     * That makes it the readiness signal for [AiProviderType.LOCAL] -- a
     * provider whose "credentials" are a running process.
     *
     * Stored in plain preferences rather than encrypted alongside the keys,
     * because `http://127.0.0.1:41234` is not a secret and encrypting it would
     * put a loopback port through the Keystore for no benefit.
     */
    fun localBaseUrl(): String? = preferences.getString(KEY_LOCAL_BASE_URL, null)

    /** @see localBaseUrl */
    fun saveLocalBaseUrl(url: String?) {
        val editor = preferences.edit()
        if (url.isNullOrBlank()) editor.remove(KEY_LOCAL_BASE_URL) else editor.putString(KEY_LOCAL_BASE_URL, url.trim())
        editor.commit()
    }

    // -- The endpoint the active provider is actually built with ------------

    /**
     * Where a provider's requests go, read from the preference that provider
     * actually uses.
     *
     * There are three endpoint preferences and they are not interchangeable:
     * [Assistant] builds Anthropic with [baseUrl], OpenAI with [openAiBaseUrl]
     * and Custom with [customBaseUrl]. The settings screen wrote [baseUrl] for
     * all of them, so the endpoint field was **inert for three providers out of
     * four** -- including Custom, whose only reason to exist is pointing at an
     * address of your own. It looked saved, and every request still went to the
     * default host.
     *
     * Gemini has no endpoint preference at all: [GeminiAiClient] takes no base
     * URL, so there is nothing to return and nothing to write.
     */
    fun providerBaseUrl(provider: AiProviderType): String? = when (provider) {
        AiProviderType.ANTHROPIC -> baseUrl()
        AiProviderType.OPENAI -> openAiBaseUrl()
        AiProviderType.CUSTOM -> customBaseUrl()
        AiProviderType.LOCAL -> localBaseUrl()
        AiProviderType.GEMINI -> null
    }

    fun saveProviderBaseUrl(provider: AiProviderType, endpoint: Endpoint) {
        if (endpoint is Endpoint.Rejected) return
        val url = (endpoint as? Endpoint.Custom)?.baseUrl
        when (provider) {
            AiProviderType.ANTHROPIC -> saveBaseUrl(endpoint)
            AiProviderType.OPENAI -> saveOpenAiBaseUrl(url)
            AiProviderType.CUSTOM -> saveCustomBaseUrl(url)
            // Written by whatever started the server, not typed by anyone.
            AiProviderType.LOCAL -> saveLocalBaseUrl(url)
            AiProviderType.GEMINI -> Unit
        }
    }

    // -- Clear / Removal ----------------------------------------------------

    /**
     * Forgets one provider's key, leaving the other three alone.
     *
     * The Keystore alias is deliberately **not** deleted: it is shared by every
     * provider, and deleting it turns the keys that were meant to survive into
     * undecryptable ciphertext. Only [clear], which removes them all in the same
     * breath, may take the alias with it.
     *
     * Gemini's Google tokens are not touched either -- signing out is its own
     * action, and it is the only one that should end a session.
     */
    fun clearProviderKey(provider: AiProviderType) {
        val editor = preferences.edit()
        when (provider) {
            AiProviderType.GEMINI -> editor
                .remove(KEY_GEMINI_KEY_CIPHER)
                .remove(KEY_GEMINI_IV)
            AiProviderType.OPENAI -> editor
                .remove(KEY_OPENAI_KEY_CIPHER)
                .remove(KEY_OPENAI_IV)
            // Anthropic answers to two slots: the legacy pair predates providers
            // and is still what save()/read() use for it.
            AiProviderType.ANTHROPIC -> editor
                .remove(KEY_CIPHERTEXT)
                .remove(KEY_IV)
                .remove(KEY_ANTHROPIC_KEY_CIPHER)
                .remove(KEY_ANTHROPIC_IV)
            AiProviderType.CUSTOM -> editor
                .remove(KEY_CUSTOM_KEY_CIPHER)
                .remove(KEY_CUSTOM_IV)
            // No key to forget. The address is not a credential and is cleared
            // when the server stops, not when a user asks to forget a secret.
            AiProviderType.LOCAL -> editor
        }
        editor.commit()
    }

    /** Forgets all keys. Preserves base URLs as per specification. */
    fun clear() {
        preferences.edit()
            .remove(KEY_CIPHERTEXT)
            .remove(KEY_IV)
            .remove(KEY_GEMINI_KEY_CIPHER)
            .remove(KEY_GEMINI_IV)
            .remove(KEY_OPENAI_KEY_CIPHER)
            .remove(KEY_OPENAI_IV)
            .remove(KEY_ANTHROPIC_KEY_CIPHER)
            .remove(KEY_ANTHROPIC_IV)
            .remove(KEY_CUSTOM_KEY_CIPHER)
            .remove(KEY_CUSTOM_IV)
            .remove(KEY_GOOGLE_ACCESS_TOKEN_CIPHER)
            .remove(KEY_GOOGLE_ACCESS_TOKEN_IV)
            .remove(KEY_GOOGLE_REFRESH_TOKEN_CIPHER)
            .remove(KEY_GOOGLE_REFRESH_TOKEN_IV)
            .remove(KEY_GOOGLE_USER_EMAIL)
            .remove(KEY_GOOGLE_USER_NAME)
            .remove(KEY_GOOGLE_GRANTED_SCOPES)
            .commit()
        runCatching { keyStore().deleteEntry(alias) }
    }

    // -- Keystore AES-GCM Encryption / Decryption ---------------------------

    private fun encryptAndStore(cipherKeyPref: String, ivKeyPref: String, plaintext: String) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())

        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        preferences.edit()
            .putString(cipherKeyPref, Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .putString(ivKeyPref, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .commit()
    }

    private fun decryptPreference(cipherKeyPref: String, ivKeyPref: String): String? {
        val ciphertext = preferences.getString(cipherKeyPref, null) ?: return null
        val iv = preferences.getString(ivKeyPref, null) ?: return null

        return runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(
                Cipher.DECRYPT_MODE,
                existingSecretKey() ?: return null,
                GCMParameterSpec(TAG_BITS, Base64.decode(iv, Base64.NO_WRAP)),
            )
            String(cipher.doFinal(Base64.decode(ciphertext, Base64.NO_WRAP)), Charsets.UTF_8)
        }.getOrNull()
    }

    private val alias: String get() = namespaced(ALIAS)

    private fun namespaced(name: String) = namespace?.let { "$name.$it" } ?: name

    private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    private fun existingSecretKey(): SecretKey? =
        runCatching { keyStore().getKey(alias, null) as? SecretKey }.getOrNull()

    private fun secretKey(): SecretKey = existingSecretKey() ?: generateSecretKey()

    private fun generateSecretKey(): SecretKey =
        KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER).apply {
            init(
                KeyGenParameterSpec.Builder(
                    alias,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setUserAuthenticationRequired(false)
                    .build(),
            )
        }.generateKey()

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val ALIAS = "aide.ai.apikey"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val TAG_BITS = 128

        const val FILE = "aide-ai"

        const val KEY_ACTIVE_PROVIDER = "provider.active"
        const val KEY_SHARE_CONTEXT = "settings.share_context"

        // Legacy / Anthropic keys
        const val KEY_CIPHERTEXT = "apiKey.ciphertext"
        const val KEY_IV = "apiKey.iv"
        const val KEY_BASE_URL = "endpoint.baseUrl"

        // Gemini
        const val KEY_GEMINI_KEY_CIPHER = "gemini.apiKey.ciphertext"
        const val KEY_GEMINI_IV = "gemini.apiKey.iv"
        const val KEY_GOOGLE_ACCESS_TOKEN_CIPHER = "google.oauth.access.ciphertext"
        const val KEY_GOOGLE_ACCESS_TOKEN_IV = "google.oauth.access.iv"
        const val KEY_GOOGLE_REFRESH_TOKEN_CIPHER = "google.oauth.refresh.ciphertext"
        const val KEY_GOOGLE_REFRESH_TOKEN_IV = "google.oauth.refresh.iv"
        const val KEY_GOOGLE_USER_EMAIL = "google.user.email"
        const val KEY_GOOGLE_USER_NAME = "google.user.name"

        /**
         * The scopes Google granted, which can be a subset of those requested.
         *
         * Stored, not logged: a dropped scope surfaces later as
         * `ACCESS_TOKEN_SCOPE_INSUFFICIENT` naming the method and not the
         * scope, and the device this was first diagnosed on emits no logcat at
         * all. Somewhere a person can read it is the only place that works.
         */
        const val KEY_GOOGLE_GRANTED_SCOPES = "google.granted.scopes"

        // OpenAI
        const val KEY_OPENAI_KEY_CIPHER = "openai.apiKey.ciphertext"
        const val KEY_OPENAI_IV = "openai.apiKey.iv"
        const val KEY_OPENAI_BASE_URL = "openai.baseUrl"

        // Anthropic dedicated
        const val KEY_ANTHROPIC_KEY_CIPHER = "anthropic.apiKey.ciphertext"
        const val KEY_ANTHROPIC_IV = "anthropic.apiKey.iv"

        // Custom
        const val KEY_CUSTOM_KEY_CIPHER = "custom.apiKey.ciphertext"
        const val KEY_CUSTOM_IV = "custom.apiKey.iv"
        const val KEY_CUSTOM_BASE_URL = "custom.baseUrl"
        const val KEY_LOCAL_BASE_URL = "local.baseUrl"

        fun modelKey(provider: AiProviderType): String = "model.${provider.id}"
    }
}
