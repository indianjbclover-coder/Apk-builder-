package com.osamu.aide.di

import androidx.test.platform.app.InstrumentationRegistry
import com.osamu.aide.ai.LocalModelServer
import com.osamu.aide.ai.core.ApiKeyStore
import com.osamu.aide.ai.core.Assistant
import com.osamu.aide.engine.fast.KotlinToolchainProvider
import com.osamu.aide.ui.workspace.AssistantViewModel
import com.osamu.aide.ui.workspace.KotlinCompilerSource
import com.osamu.aide.ui.workspace.LanguageServices
import com.osamu.aide.ui.workspace.GitViewModel
import com.osamu.aide.ui.workspace.ProjectBuilder
import com.osamu.aide.vcs.git.GitCredentialStore
import com.osamu.aide.core.common.DispatcherProvider
import com.osamu.aide.toolchain.manager.ToolchainManager
import com.osamu.aide.vcs.git.GitIdentityStore
import com.osamu.aide.vcs.git.GitWorkspace
import org.junit.After
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.koin.dsl.koinApplication
import org.koin.dsl.module
import java.io.File

/**
 * That the object graph resolves on a device with nothing installed.
 *
 * This is the test the app was missing. `single<KotlinCompiler?>` looked
 * reasonable and every unit test built its objects by hand, so nobody
 * discovered that **Koin cannot hold null in a singleton** until a project was
 * opened on a device without the Kotlin toolchain -- which is the ordinary
 * state, since the compiler is a 54 MB download. The whole graph came down with
 * `IllegalStateException: Single instance created couldn't return value`, three
 * frames below a Koin stack trace that named `ProjectBuilder`.
 *
 * So the assertion is not about Kotlin. It is that every definition a workspace
 * needs can actually be constructed on a bare device, which is the only
 * configuration a new user has.
 */
class AppModuleTest {

    /**
     * **An isolated Koin, not the global one.** This runs in the app's process,
     * where `AideApplication` has already started Koin globally: `startKoin`
     * here threw KoinApplicationAlreadyStartedException when this test ran
     * alone, and passed in a full run only because the other test in the class
     * happened to run first -- and its `stopKoin()` then tore down the
     * application's own Koin, so every later test that composes a
     * `koinInject()` caller failed with "KoinApplication has not been started".
     * `koinApplication {}` builds the same graph without registering it.
     */
    private val application = koinApplication {
        modules(
            module { single { InstrumentationRegistry.getInstrumentation().targetContext } },
            appModule,
        )
    }

    @After
    fun tearDown() = application.close()

    private fun koin() = application.koin

    @Test
    fun the_graph_a_workspace_needs_resolves_with_no_toolchain_installed() {
        val koin = koin()

        assertNotNull(koin.get<ProjectBuilder>())
        // Resolved here too because it is the newest thing in the graph and
        // pulls in both the builder and the repository -- which is the shape of
        // dependency that broke last time.
        assertNotNull(koin.get<AssistantViewModel>())
        assertNotNull(koin.get<LanguageServices>())
        assertNotNull(koin.get<Assistant>())
        assertNotNull(koin.get<ApiKeyStore>())
        // The on-device model server joined the graph with the LOCAL provider.
        // A singleton because it owns a `llama-server` process, which is
        // exactly the shape that must not be constructed twice -- two
        // instances would mean two servers each holding a gigabyte of model.
        assertNotNull(koin.get<LocalModelServer>())
        // Version control joined the graph with M8. GitWorkspace takes four
        // constructor arguments, two of which have defaults that Koin does not
        // use -- so a definition that named them in the wrong order would
        // compile and fail only here.
        assertNotNull(koin.get<GitWorkspace>())
        assertNotNull(koin.get<GitIdentityStore>())
        assertNotNull(koin.get<GitCredentialStore>())
        // The settings screen resolves these two directly rather than through
        // a view model, so nothing else in this test would notice if either
        // left the graph -- and the failure would be a crash on opening
        // Settings, which is not where anyone would look for it.
        assertNotNull(koin.get<ToolchainManager>())
        assertNotNull(koin.get<DispatcherProvider>())
        // Resolved rather than assumed because it takes an unqualified `File`,
        // and the module defines two: the workspace root and, under a name, the
        // build output root. Koin picks the unnamed one, which is correct and
        // is exactly the kind of binding that breaks silently when a third
        // `File` is added.
        assertNotNull(koin.get<GitViewModel>())
    }

    /**
     * And the absence itself is still expressible.
     *
     * The fix would be worthless if it papered over "not installed" with a
     * broken compiler: a build would start and fail in the middle rather than
     * refusing up front and naming the missing component.
     *
     * Built against an empty directory rather than resolved from Koin, because
     * whether *this* device has a toolchain is not the question -- and asking
     * Koin would make the test pass or fail on whatever an earlier run happened
     * to download.
     */
    @Test
    fun a_missing_kotlin_compiler_is_reported_as_absent_rather_than_fabricated() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val empty = File(context.cacheDir, "no-toolchain-${System.nanoTime()}")

        val source = KotlinCompilerSource(KotlinToolchainProvider(emptyContext(empty)), empty)

        assertNull(source.compiler())
    }

    /** A Context whose filesDir is [root], so the provider finds nothing. */
    private fun emptyContext(root: File): android.content.Context =
        object : android.content.ContextWrapper(
            InstrumentationRegistry.getInstrumentation().targetContext,
        ) {
            override fun getFilesDir(): File = root.apply { mkdirs() }
        }
}
